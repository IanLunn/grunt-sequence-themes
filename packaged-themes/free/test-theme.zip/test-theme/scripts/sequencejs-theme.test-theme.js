/*!
 * Sequence.js Theme
 *
 * Theme Name: Theme Test
 * Version: 1.0
 * Theme URL: http://sequencejs.com/themes/theme-test/
 *
 * Author: Ian Lunn @IanLunn
 * Author URL: http://ianlunn.co.uk/
 *
 * This theme is made available under a MIT License:
 * http://www.opensource.org/licenses/mit-license.php
 *
 * Sequence.js and its dependencies are copyright (c) Ian Lunn 2014 unless otherwise stated.
 */
